
import json,os
from pathlib import Path
os.environ['HF_HOME']='/workspace/hf-cache'
os.environ['HF_HUB_DISABLE_IMPLICIT_TOKEN']='1'
from huggingface_hub import snapshot_download
out={}
for name in ['jhu-clsp/mmBERT-base','jhu-clsp/mmBERT-small','Qwen/Qwen3.5-0.8B','knowledgator/gliclass-x-base']:
    path=snapshot_download(name,allow_patterns=['*.json','*.safetensors','*.model','*.txt'],max_workers=4)
    out[name]={'snapshot':path,'revision':Path(path).name}
    Path('results/pilot-student-h200-20260927/backbone_sources.json').write_text(json.dumps(out,indent=2))
    print(name,Path(path).name,flush=True)
