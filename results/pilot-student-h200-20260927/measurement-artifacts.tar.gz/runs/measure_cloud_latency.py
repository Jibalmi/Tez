
import json,subprocess,sys,time
from pathlib import Path
root=Path('/workspace/tez-student')
out=root/'results/pilot-student-h200-20260927/cloud-latency'
status=[]
for arm in ['a-base-30k','a-small-30k','c-qwen08-30k']:
    start=time.monotonic()
    with (out/(arm+'.log')).open('w') as log:
        p=subprocess.run([sys.executable,str(root/'runs/latency_cloud.py'),'--arm',arm,'--device','cuda',
            '--warmup','5','--reps','40','--reps50','15'],stdout=log,stderr=subprocess.STDOUT,timeout=240)
    status.append({'arm':arm,'returncode':p.returncode,'seconds':time.monotonic()-start})
    (out/'execution.json').write_text(json.dumps(status,indent=2))
(out/'complete.json').write_text(json.dumps({'all_passed':all(x['returncode']==0 for x in status)}))
